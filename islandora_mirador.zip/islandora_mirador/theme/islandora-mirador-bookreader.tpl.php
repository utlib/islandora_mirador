<?php

/**
 * @file
 *
 * Theme for Mirador BookReader.
 */

?>
<div id="mirador-bookreader" class="islandora-mirador-bookreader mirador-reader"></div>
