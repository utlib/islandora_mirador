(function($) {
  $(function() {

    /* Switch the Mirador view type based on the Drupal setting */
    var view_type = Drupal.settings.islandora_mirador_bookreader.view_type;
    var manifest_url = Drupal.settings.islandora_mirador_bookreader.manifest_url;
    var canvas_url = Drupal.settings.islandora_mirador_bookreader.canvas_url;

    console.log("Manifest URL: " + manifest_url + ", Canvas URL: " + canvas_url);

    if (!manifest_url) {
      $("#mirador-bookreader").html( "<div style='text-align:center'><img src='https://content.library.utoronto.ca/collections/no-image.png' alt='No Image Available' width='auto' height='750px' /></div>" );
    } else {
      var bottomPanel = true;
      $.getJSON(manifest_url, function(result) {
        var loadMirador = true;
        if (!result.sequences || result.sequences.length == 0) {
          loadMirador = false;
        } else if (result.sequences[0].canvases.length <= 1) {
          bottomPanel = false;
        } else if (canvas_url) {
          bottomPanel = false;
        }
        if (loadMirador) {
          setMiradorConstructor(bottomPanel, canvas_url);
          var manifest_link = "<div id=mirador-manifest-url style='margin:10px auto; width:90%;text-align:center'><a href='"+manifest_url+"'><img src='https://content.library.utoronto.ca/collections/iiif.png' alt='IIIF manifest URL' style='width:20px; height:20px; margin-right: 10px; display: inherit;'>"+manifest_url+"</a></div>";
          $("#mirador-bookreader").after(manifest_link);
        } else {
          $("#mirador-bookreader").html( "<div style='text-align:center'><img src='https://content.library.utoronto.ca/collections/no-image.png' alt='No Image Available' width='auto' height='750px' /></div>" );
        }
      });
    }
    
    function setMiradorConstructor(bottomPanel, canvas_url) {
      /* Retrieve the manifest_url and supply it to Mirador's constructor */
      Mirador({
        "id": "mirador-bookreader",
        "data":[{ "manifestUri": manifest_url, "location": "University of Toronto"}],
        'buildPath' : '/sites/all/libraries/mirador/',
        'language': 'en',
        'imagesPath' : 'images/',
        'logosPath' : 'images/logos/',
        'logosLocation' : 'logos/',
        'repoImages' : {
          'other': 'iiif_logo.png'
        },
        "windowObjects": [
          {
            "loadedManifest":manifest_url,
            "viewType":view_type,
            "sidePanel": true,
            "sidePanelVisible": false,
            "bottomPanel": bottomPanel,
            "canvasID" : canvas_url
          }
        ]
      });
    }
  });
})(jQuery);

// Make "i" icon (info button) in Mirador viewer toggle to metadata details below
function scrollToMetadata() {
  jQuery('html, body').animate({scrollTop: jQuery('.islandora-metadata').offset().top}, 1000);
}
